package com.example.layouts;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.widget.Button;
import android.content.Intent;
import android.widget.CheckBox;
import android.view.View;
import android.widget.Toast;

public class Activity_2 extends AppCompatActivity {
    public Button button;
    CheckBox Pizza,Burger,Coffee;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        Pizza=(CheckBox)findViewById(R.id.checkbox1);
        Burger=(CheckBox)findViewById(R.id.checkbox2);
        Coffee=(CheckBox)findViewById(R.id.checkbox3);

        button = (Button) findViewById(R.id.Linearbtn);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int totalamount=0;
                StringBuilder result=new StringBuilder();
                result.append("Selected Items:");
                if(Pizza.isChecked()){
                    result.append("\nPizza 100Rs");
                    totalamount+=100;
                }
                if(Burger.isChecked()){
                    result.append("\nBurger 70Rs");
                    totalamount+=70;
                }
                if(Coffee.isChecked()){
                    result.append("\nCoffee 120Rs");
                    totalamount+=120;
                }

                result.append("\nTotal: "+totalamount+"Rs");
                //Displaying the message on the toast
                Toast.makeText(getApplicationContext(), result.toString(), Toast.LENGTH_LONG).show();


                Intent intent = new Intent(Activity_2.this,Activity_3.class);
                startActivity(intent);
            }
        });
    }
}