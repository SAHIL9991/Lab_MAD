package com.example.messagealert;

public class SecondActivity {
}
